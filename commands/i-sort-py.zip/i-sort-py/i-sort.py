import os
import shutil
import re
import configparser
import subprocess

# Lire la configuration depuis un fichier de configuration
def read_config(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    return config

# Fonction pour trier un fichier
def organize_file(source_path, destination_path, create_subfolders):
    if not os.path.exists(destination_path):
        os.makedirs(destination_path)

    if create_subfolders:
        # Utilisez le motif dans le nom du fichier pour créer des sous-dossiers
        match = re.search(pattern, source_path)
        if match:
            subfolder_name = match.group(0)
            destination_path = os.path.join(destination_path, subfolder_name)
            if not os.path.exists(destination_path):
                os.makedirs(destination_path)

    shutil.move(source_path, destination_path)

# Fonction principale de tri
def organize_files(root_folder, config):
    for foldername, subfolders, filenames in os.walk(root_folder):
        for filename in filenames:
            source_path = os.path.join(foldername, filename)

            # Obtenez l'extension du fichier
            file_extension = os.path.splitext(filename)[1][1:]

            # Obtenez le motif du nom du fichier à partir de la configuration
            pattern = config.get("FilePatterns", file_extension, fallback=None)

            if pattern:
                # Déterminez si vous devez créer des sous-dossiers
                create_subfolders = config.getboolean("CreateSubfolders", file_extension, fallback=False)
                destination_path = config.get("DestinationFolders", pattern, fallback=None)

                if destination_path:
                    organize_file(source_path, destination_path, create_subfolders)
                else:
                    # Si le motif du nom du fichier n'a pas de dossier de destination, déplacez-le vers un dossier "Unspecified"
                    organize_file(source_path, os.path.join(root_folder, "Unspecified"), False)

# Fonction pour ajouter un nouveau motif ou une nouvelle extension au fichier de configuration
def add_pattern_to_config(config_file, extension, pattern, create_subfolders, destination_path):
    config = read_config(config_file)
    if not config.has_section("FilePatterns"):
        config.add_section("FilePatterns")
    if not config.has_section("CreateSubfolders"):
        config.add_section("CreateSubfolders")
    if not config.has_section("DestinationFolders"):
        config.add_section("DestinationFolders")
    config.set("FilePatterns", extension, pattern)
    config.set("CreateSubfolders", extension, str(create_subfolders))  # Convertir en chaîne
    config.set("DestinationFolders", pattern, destination_path)
    with open(config_file, "w") as configfile:
        config.write(configfile)

if __name__ == "__main__":
    config_file = "config.ini"

    # Demandez à l'utilisateur de sélectionner le dossier source avec Zenity
    root_folder = subprocess.check_output("zenity --file-selection --directory --title='Sélectionnez le dossier source'", shell=True, universal_newlines=True).strip()

    # Demandez à l'utilisateur de spécifier les valeurs à ajouter
    new_extension = subprocess.check_output("zenity --entry --title='Nouvelle Extension' --text='Entrez la nouvelle extension :'", shell=True, universal_newlines=True).strip()
    new_pattern = subprocess.check_output("zenity --entry --title='Nouveau Motif' --text='Entrez le nouveau motif :'", shell=True, universal_newlines=True).strip()
    new_create_subfolders = subprocess.check_output("zenity --question --title='Créer des sous-dossiers ?' --text='Voulez-vous créer des sous-dossiers ?'", shell=True, universal_newlines=True).strip() == "true"
    new_destination_path = subprocess.check_output("zenity --file-selection --title='Sélectionnez un dossier de destination' --directory", shell=True, universal_newlines=True).strip()

    add_pattern_to_config(config_file, new_extension, new_pattern, new_create_subfolders, new_destination_path)

    config = read_config(config_file)
    organize_files(root_folder, config)

