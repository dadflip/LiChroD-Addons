#!/bin/bash

sudo apt install -y adb
adb connect arc
echo "TERMINÉ"