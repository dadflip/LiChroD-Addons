#!/bin/bash


sudo apt install -y timeshift
echo "install verified" > /etc/timeshift-verif-file
echo "TERMINÉ"
