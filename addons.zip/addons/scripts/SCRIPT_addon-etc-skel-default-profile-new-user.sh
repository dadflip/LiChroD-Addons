#!/bin/bash

cd /etc/skel
sudo mkdir Documents Images Musiques
cd
echo "TERMINÉ"
#adduser usertest
#cd /home/usertest/
